import React, { useEffect, useState } from "react";
import styled from "styled-components";

const MapContainer = styled.div`
    width: 700px;
    height: 400px;
`;

const { kakao } = window;

//불러오는 부모페이지에서 props로 location={pageDetail}전달
export const KakaoMap = ({ initlocation }) => {
    initlocation = initlocation || {location_x:35, location_y: 127}; //초기값 설정
    const [location,setLocation] = useState(initlocation); //초기값 설정
    
    useEffect(() => {
        var container = document.getElementById("map"); //지도를 담을 영역의 DOM 레퍼런스
        var options = {
            center: new kakao.maps.LatLng(
                location.location_x,
                location.location_y
            ), //지도의 중심좌표
            level: 3,
        };

        var map = new kakao.maps.Map(container, options); //지도 생성 및 객체 리턴
        var markerPosition = new kakao.maps.LatLng(
            location.location_x,
            location.location_y
        ); //해당 위치 마커 표시
        var marker = new kakao.maps.Marker({
            position: markerPosition,
        });
        marker.setMap(map);
    }, [location]);

    return (
        <div>
            <MapContainer id="map"></MapContainer>
            <button onClick={() => setLocation({ location_x: 37.506320759000715, location_y: 127.05368251210247 })}>
                바꾸기
            </button>
        </div>
    );
};