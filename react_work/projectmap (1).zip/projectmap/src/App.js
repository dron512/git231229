import "./App.css";
import { Routes, Route } from "react-router-dom";
import Maps from "./pages/Map";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Maps />}></Route>
      </Routes>
    </div>
  );
}

export default App;
