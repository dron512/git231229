import { useEffect, useState } from "react";
import { Map, MapMarker } from "react-kakao-maps-sdk";
import axios from "axios";

// 주소를 좌표로 바꾸는거
const getAddr = (addr) => {
  return new Promise((resolve, reject) => {
    const geocoder = new window.kakao.maps.services.Geocoder();

    geocoder.addressSearch(`${addr}`, function (result, status) {
      if (status === window.kakao.maps.services.Status.OK) {
        const coords = {
          lat: result[0].y,
          lng: result[0].x,
        };
        resolve(coords);
      } else reject(status);
    });
  });
};

const marketInfo = async () => {
  var infos = [
    {
      marketname: "",
      address: "",
      delivery: "",
      opentime: "",
      closetime: "",
      phonenumber: "",
    },
  ];

  infos = await axios.get("http://localhost:8080/map/address");

  return infos;
};

const Maps = () => {

  const [loading, setLoading] = useState(true); // 로딩 중 여부 상태

  const [addrs, setAddrs] = useState([
    {
      id: 0,
      position: {
        lat: 0,
        lng: 0,
      },
    },
  ]);

  // 현재 좌표가져오기
  const mygeo = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function (position) {
        setPoint({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setmarkerP({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      });
    }
  };

  const [point, setPoint] = useState({
    lat: 0,
    lng: 0,
  });

  const [markerP, setmarkerP] = useState({
    lat: 0,
    lng: 0,
  });

  const [markers, setMarkers]   = useState(()=>{return [
    { id: 1, position: { lat: 35.4886, lng: 128.7507 } },
    { id: 2, position: { lat: 35.488409716369645, lng: 128.75016683308854 } },
    { id: 3, position: { lat: 35.48880652555993, lng: 128.74952534400953 } },
  ]});

  useEffect(() => {
    mygeo();

    const getMarkerInfo = async () => {
      const result = await marketInfo();
      if (result.data != null) {
        addrs.splice(0, 1);
        for (let i = 0; i < result.data.length; i++) {
          await getAddr(result.data[i].address).then((coords) => {
            addrs.push({
              id: i,
              position: { lat: coords.lat, lng: coords.lng },
            });
          });
        }
        console.log("addrs 출력");
        console.log(addrs);
        setMarkers(addrs);

        setLoading(false); // 로딩 상태 업데이트
      }
    };
    getMarkerInfo();

  }, [markers]);

  if (loading) {
    return <div>Loading...</div>;
  }


  return (
    <>
      <div className="map_wrap">
        <div>

          <Map
            center={point}
            style={{
              width: "100%",
              height: "500px",
            }}
            level={3}
            onDragEnd={(map) => {
              const latlng = map.getCenter();
              setPoint({
                lat: latlng.getLat(),
                lng: latlng.getLng(),
              });
            }}
          >
            <MapMarker
              position={markerP}
              image={{
                src: "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png",
                size: [24, 35],
              }}
            ></MapMarker>
            {  markers.map((marker) => {
              return <MapMarker key={marker.id} position={marker.position} />;
            })}
          </Map>
          <div className="custom_mygps">
            <button onClick={mygeo}>내위치</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Maps;
