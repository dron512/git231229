
localStorage.removeItem("access_token");
localStorage.removeItem("refresh_token");

window.location.href = 'http://localhost:3000/'

const LogoutkakaoPage = () => {
    return ( 
        <>
        
        </>
     );
}
 
export default LogoutkakaoPage;