import React from "react";

const PaymentFailPage = () => {
  return <div>PaymentFailPage</div>;
};

export default PaymentFailPage;
