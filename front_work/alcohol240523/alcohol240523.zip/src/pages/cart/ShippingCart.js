import React from "react";

const ShippingCart = () => {
  return <div>ShippingCart</div>;
};

export default ShippingCart;
