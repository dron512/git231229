import styled from "@emotion/styled/macro";

export const payLayout = styled.div`
  min-width: 1300px;
  padding: 130px 250px 130px 250px;
  /* background: rebeccapurple; */
`;