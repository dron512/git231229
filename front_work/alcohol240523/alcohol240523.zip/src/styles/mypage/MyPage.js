import styled from "@emotion/styled/macro";
import React from "react";

const MyPageContent = styled.h1`
    font-size: 2rem;
    color:#FF4D35;
`;
export default MyPageContent;
