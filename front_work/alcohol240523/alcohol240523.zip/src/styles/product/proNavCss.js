import styled from "@emotion/styled/macro";

export const HeaderNavWrap = styled.div`
  display: flex;
  position: relative;
  justify-content: center;
  gap: 50px;
`;
