import styled from "@emotion/styled/macro";

export const MyWrap = styled.div`
  width: 100%;
  padding: 50px 0 50px 0;
  display: flex;
  position: relative;
  /* background-color: aqua; */
`;

export const InfoWrap = styled.div`
  width: 100%;
  display: table-row;
  position: relative;
`;
