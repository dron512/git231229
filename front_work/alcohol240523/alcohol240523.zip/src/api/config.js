export const SERVER_URL = "http://192.168.0.8:8080";

export const API_SEVER_URL = "";
