import { atom } from "recoil";

export const addressState = atom({
  key: "addressState",
  default: "",
});
