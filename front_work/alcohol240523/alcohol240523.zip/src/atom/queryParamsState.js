import { atom } from "recoil";

export const queryParamsState = atom({
  key: "queryParamsState",
  default: {},
});
