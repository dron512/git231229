import { atom } from "recoil";

export const activeSideState = atom({
  key: "activeSideState",
  default: null,
});
