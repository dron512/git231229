export const PCartData = [
  {
    key: 1,
    pic: "/images/moon.jpg",
    info: "고라니가 파는 술집",
    count: 8,
    price: 30000,
    testnum: "34343405",
  },
  {
    key: 2,
    pic: "/images/moon.jpg",
    info: "고라니가 파는 술집",
    count: 3,
    price: 30000,
    testnum: "34343405",
  },
  {
    key: 3,
    pic: "/images/moon.jpg",
    info: "고라니가 파는 술집",
    count: 3,
    price: 30000,
    testnum: "34343405",
  },
  {
    key: 4,
    pic: "/images/moon.jpg",
    info: "고라니가 파는 술집",
    count: 10,
    price: 30000,
    testnum: "34343405",
  },
];

export const picPriceData = [
  {
    key: "1",
    price: 10000,
    sh: 3000,
  },
  {
    key: "2",
    price: 10000,
    sh: 3000,
    total: null,
  },
  {
    key: "3",
    price: 10000,
    sh: 3000,
    total: null,
  },
  {
    key: "4",
    price: 10000,
    sh: 3000,
    total: null,
  },
];
