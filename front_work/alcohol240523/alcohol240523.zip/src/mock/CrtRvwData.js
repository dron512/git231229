export const reviewData = [
  {
    key: "1",
    name: "John Brown",
    date: "2024 - 04 - 22",
    math: "고라니가 파는 술집",
    order: "픽업",
    test: "주문명1 문상훈",
    testnum: "34343405",
    // button: 70,
  },
  {
    key: "2",
    name: "Jim Green",
    chinese: 98,
    math: 66,
    button: 89,
  },
  {
    key: "3",
    name: "Joe Black",
    chinese: 98,
    math: 90,
    button: 70,
  },
  {
    key: "4",
    name: "Jim Red",
    chinese: 88,
    math: 99,
    button: 89,
  },
];

export const MyreviewData = [
  {
    key: "1",
    productNm: "고라니가 먹으면 죽어요 진짜",
    star: 4,
    date: "2024 - 04 - 22",
    storeNm: "고라니가 파는 술집",
    content:
      "이야 진짜 먹고 고라니가 됐습니다. 고라니 친구들이랑 같이 놀다보니 눈떠보니 경찰서에 있더라구요 정말 좋은 경험 했습니다 종종 사먹으러 오는 좋은 아이입니다.",
  },
  {
    key: "2",
    productNm: "고라니가 먹으면 죽어요 진짜",
    star: 1,
    date: "2024 - 04 - 22",
    storeNm: "고라니가 파는 술집",
    content:
      "이야 진짜 먹고 고라니가 됐습니다. 고라니 친구들이랑 같이 놀다보니 눈떠보니 경찰서에 있더라구요 정말 좋은 경험 했습니다 종종 사먹으러 오는 좋은 아이입니다.",
  },
];
