export const ProductItemData = [
  {
    name: "나는 술을 좋아하는 고라니 1set",
    introduction: "상품소개 : 쌀쌀한 겨울에",
    stars: 4,
    price: 34000,
  },
];
