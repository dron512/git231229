export const categoryData = [
  {
    main: "위스키",
    subs: ["싱글몰트", "브랜디드", "버번"],
  },
  {
    main: "와인",
    subs: ["레드 와인", "화이트 와인", "스파클링 와인", "로제 와인"],
  },
  {
    main: "리큐르",
    subs: [], // LIQUEUR은 서브 카테고리가 없는 것으로 가정
  },
  {
    main: "브랜디",
    subs: ["꼬냑", "깔바도스", "아르마냑"],
  },
];
