export const getNum = (check, basic) => {
  if (!check) {
    return basic;
  }
  return check;
};

export const API_SERVER_HOST = "";
