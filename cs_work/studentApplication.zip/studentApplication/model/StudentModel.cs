﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentApplication.model
{
    public class StudentModel
    {
        public int Idx { get; set; }
        public string Name { get; set; }
        public int Math { get; set; }
        public int Eng { get; set; }
        public int Kor { get; set; }
    }
}
