import React from "react";

const OrderPickPage = () => {
  return <div>픽업배송조회</div>;
};

export default OrderPickPage;
