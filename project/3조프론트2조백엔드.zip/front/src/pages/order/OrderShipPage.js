import React from "react";

const OrderShipPage = () => {
  return <div>배송조회</div>;
};

export default OrderShipPage;
