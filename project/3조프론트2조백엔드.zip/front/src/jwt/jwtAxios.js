// import axios from "axios";

// export const locinCheck = () => {
//   const accessToken = axios.get("/auth/login", {});
//   localStorage.setItem("accessToken", accessToken);
// };

// export const getItem = () => {
//   const accessToken = localStorage.getItem("accessToken");
//   const listData = axios.post("/item/list", {
//     Authorization: `Bearer ${accessToken}`,
//   });
// };

// export const getSearchName = async () => {
//   const listData = axios.post("/search/name", {
//     id: 0,
//     name: "레",
//     maincategory: "string",
//     subcategory: "string",
//   });
//   return listData;
// };
