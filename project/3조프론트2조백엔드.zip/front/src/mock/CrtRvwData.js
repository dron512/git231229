export const reviewData = [
  {
    key: "1",
    name: "John Brown",
    date: "2024 - 04 - 22",
    math: "고라니가 파는 술집",
    order: "픽업",
    test: "주문명1 문상훈",
    testnum: "34343405",
    // button: 70,
  },
  {
    key: "2",
    name: "Jim Green",
    chinese: 98,
    math: 66,
    button: 89,
  },
  {
    key: "3",
    name: "Joe Black",
    chinese: 98,
    math: 90,
    button: 70,
  },
  {
    key: "4",
    name: "Jim Red",
    chinese: 88,
    math: 99,
    button: 89,
  },
];
