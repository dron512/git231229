export const dummyData = [
  {
    name: "그린아카데미",
    address: "대구 중구 더미주소 123",
    phoneNumber: "010-1234-5678",
    hours: "월~일 09:00 ~ 18:00",
  },
  {
    name: "블루아카데미",
    address: "서울 강남구 더미주소 456",
    phoneNumber: "010-9876-5432",
    hours: "월~일 10:00 ~ 19:00",
  },
  {
    name: "옐로아카데미",
    address: "부산 남구 더미주소 789",
    phoneNumber: "010-5555-6666",
    hours: "월~일 08:00 ~ 17:00",
  },
];
