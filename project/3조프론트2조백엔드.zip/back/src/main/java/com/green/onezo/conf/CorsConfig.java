package com.green.onezo.conf;

public class CorsConfig {
}
