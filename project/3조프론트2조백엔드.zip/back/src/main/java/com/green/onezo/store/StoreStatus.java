package com.green.onezo.store;

public enum StoreStatus {
    OPEN, CLOSED
}
