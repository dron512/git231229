package com.green.onezo.enum_column;

import lombok.Getter;
import lombok.Setter;


public enum Role {
    USER,ADMIN,STORE
}
