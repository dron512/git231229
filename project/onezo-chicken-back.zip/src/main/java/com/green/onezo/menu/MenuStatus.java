package com.green.onezo.menu;

// 일시 품절 솔드아웃
public enum MenuStatus {
    ORDERABLE, UNORDERABLE, SOLD_OUT
}
