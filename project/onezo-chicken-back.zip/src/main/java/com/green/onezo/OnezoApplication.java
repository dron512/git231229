package com.green.onezo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


// 찬우 수민 지훈 -> 관리자??
@SpringBootApplication
public class OnezoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnezoApplication.class, args);

	}

}
