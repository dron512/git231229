package com.green.onezo.cart;

public enum TakeInOut {
    IN, OUT
}
