package com.green.onezo.menu;

public enum MenuCategory {
     ALL, SET, CHICKEN, SIDE, DRINK, SAUCE
}
