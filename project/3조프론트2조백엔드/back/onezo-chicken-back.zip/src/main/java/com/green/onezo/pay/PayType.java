package com.green.onezo.pay;

public enum PayType {

    CASH,CARD,POINT
}
