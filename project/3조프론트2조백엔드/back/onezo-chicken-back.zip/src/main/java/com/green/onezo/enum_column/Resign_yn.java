package com.green.onezo.enum_column;

public enum Resign_yn {
    Y,N
}
